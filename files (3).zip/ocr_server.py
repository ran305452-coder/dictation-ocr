import os
os.environ['PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK'] = 'True'

import base64
import re
from io import BytesIO

import numpy as np
from PIL import Image, ImageEnhance
from flask import Flask, request, jsonify
from flask_cors import CORS
from paddleocr import PaddleOCR

app = Flask(__name__)
CORS(app)

print("正在初始化 OCR 模型（請稍候）...")
ocr = PaddleOCR(
    lang='chinese_cht',
    det_db_thresh=0.2,
    det_db_box_thresh=0.4,
    det_db_unclip_ratio=2.0,
    rec_batch_num=1,
    use_angle_cls=False,
    enable_mkldnn=False,
    cpu_threads=1,
    show_log=False,
)
print("✅ OCR 模型載入完成！")


def cjk_only(text):
    return re.sub(r'[^\u4e00-\u9fff\u3400-\u4dbf]', '', text)


def b64_to_np(b64_str):
    if ',' in b64_str:
        b64_str = b64_str.split(',')[1]
    img = Image.open(BytesIO(base64.b64decode(b64_str))).convert('RGB')
    return np.array(img)


def preprocess_image(img_np):
    img = Image.fromarray(img_np).convert('RGB')
    img = ImageEnhance.Contrast(img).enhance(1.8)
    w, h = img.size
    padded = Image.new('RGB', (w + 60, h + 60), (255, 255, 255))
    padded.paste(img, (30, 30))
    return np.array(padded)


def ocr_single(img_np):
    """對單張圖片執行 OCR，嘗試多種格式繞開 primitive bug"""
    h, w = img_np.shape[:2]
    if h < 64 or w < 64:
        img = Image.fromarray(img_np)
        padded = Image.new('RGB', (max(w, 64), max(h, 64)), (255, 255, 255))
        padded.paste(img, (0, 0))
        img_np = np.array(padded)

    # 嘗試策略：原圖、灰階轉回RGB、不同長寬比
    candidates = []

    # 策略1: 原圖不同尺寸
    for sw, sh in [(800,400),(640,320),(960,480),(512,256),(400,200)]:
        arr = np.array(Image.fromarray(img_np).resize((sw, sh), Image.LANCZOS))
        candidates.append(arr)

    # 策略2: 灰階轉回 RGB（改變記憶體排列）
    for sw, sh in [(800,400),(640,320),(960,480)]:
        arr = np.array(
            Image.fromarray(img_np).convert('L').convert('RGB').resize((sw, sh), Image.LANCZOS)
        )
        candidates.append(arr)

    # 策略3: 正方形
    for sz in [400, 512, 300]:
        arr = np.array(Image.fromarray(img_np).resize((sz, sz), Image.LANCZOS))
        candidates.append(arr)

    for arr in candidates:
        try:
            result = ocr.ocr(arr, cls=False)
            all_text = ''
            max_conf = 0.0
            if result and result[0]:
                for line in result[0]:
                    if line and len(line) >= 2:
                        txt, conf = line[1]
                        all_text += txt
                        if conf > max_conf:
                            max_conf = conf
            if all_text:
                return all_text, max_conf
        except Exception as e:
            if 'primitive' in str(e).lower() or 'execute' in str(e).lower():
                continue
            print(f"[DEBUG] ocr error: {e}")
            return '', 0.0
    return '', 0.0


def run_ocr(img_np):
    """整張 + 多種切割，智慧合併結果"""
    img_np = preprocess_image(img_np)
    h, w = img_np.shape[:2]

    # 1. 整張圖辨識
    t, c = ocr_single(img_np)
    whole_cjk = cjk_only(t)
    print(f"[DEBUG] whole: cjk='{whole_cjk}' conf={c:.2f}")

    # 如果整張辨識信心度高，直接用
    if whole_cjk and c >= 0.80:
        return whole_cjk, c

    # 2. 切成左右兩半，每半只取「最高信心度的單一字」
    collected = list(whole_cjk)  # 從整張結果開始
    collected_conf = c

    for ratio in [0.5, 0.4, 0.6]:
        split = int(w * ratio)
        for i, region in enumerate([img_np[:, :split], img_np[:, split:]]):
            img = Image.fromarray(region)
            padded = Image.new('RGB', (img.width + 60, img.height + 40), (255, 255, 255))
            padded.paste(img, (30, 20))
            t2, c2 = ocr_single(np.array(padded))
            cjk_t2 = cjk_only(t2)

            # 只接受長度 1~2 且信心度 >= 0.6 的結果
            if cjk_t2 and c2 >= 0.60 and len(cjk_t2) <= 2:
                print(f"[DEBUG] split{int(ratio*100)}[{i}]: cjk='{cjk_t2}' conf={c2:.2f}")
                for ch in cjk_t2:
                    if ch not in collected:
                        collected.append(ch)
                        if c2 > collected_conf:
                            collected_conf = c2

    result = ''.join(collected)
    print(f"[DEBUG] merged: '{result}'")
    return result, collected_conf


@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'engine': 'PaddleOCR', 'lang': 'chinese_cht'})


@app.route('/ocr', methods=['POST'])
def do_ocr():
    try:
        data = request.get_json()
        if not data or 'image' not in data:
            return jsonify({'error': '缺少 image 欄位'}), 400

        img_np   = b64_to_np(data['image'])
        expected = data.get('expected', '')
        mode     = data.get('mode', 'score')

        all_text, max_conf = run_ocr(img_np)
        cjk_text = cjk_only(all_text)

        print(f"[OCR] mode={mode} expected='{expected}' recognized='{cjk_text}' conf={max_conf:.2f}")

        if mode == 'wordlist':
            return jsonify({'raw': all_text.strip(), 'cjk': cjk_text, 'confidence': round(max_conf, 3)})

        if not cjk_text:
            return jsonify({'recognized': '?', 'correct': False, 'score': 0,
                           'detail': '字跡無法辨識，請寫清楚一點', 'confidence': 0.0})

        if expected:
            chars_found   = [c for c in expected if c in cjk_text]
            chars_missing = [c for c in expected if c not in cjk_text]
            score   = round(len(chars_found) / len(expected) * 100)
            correct = len(chars_missing) == 0
            if correct:
                detail = '寫對了！'
            elif chars_found:
                detail = f'找到「{"".join(chars_found)}」，但缺少「{"".join(chars_missing)}」'
            else:
                detail = f'辨識為「{cjk_text}」，正確應為「{expected}」'
        else:
            correct, score, detail = True, 100, '完成'

        print(f"[OCR] expected='{expected}' cjk='{cjk_text}' found={chars_found if expected else []} score={score}")

        return jsonify({'recognized': cjk_text, 'correct': correct, 'score': score,
                       'detail': detail, 'confidence': round(max_conf, 3)})

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    import os
    port = int(os.environ.get('PORT', 5000))
    print("\n" + "=" * 45)
    print("  國語聽寫系統 OCR 伺服器")
    print(f"  網址：http://0.0.0.0:{port}")
    print("=" * 45 + "\n")
    app.run(host='0.0.0.0', port=port, debug=False)
